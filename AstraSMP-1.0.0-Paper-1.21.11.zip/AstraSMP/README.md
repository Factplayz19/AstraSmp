# AstraSMP 1.0.0

Mahabharata-inspired Astra SMP plugin for Paper 1.21.11 / Java 21.

## Build
1. Install Java 21 and Maven.
2. Run `mvn clean package`.
3. Put `target/AstraSMP-1.0.0.jar` into the Paper server's `plugins` folder.
4. Restart the server.

## Notes
- Astra ownership uses UUID + PersistentDataContainer.
- Astra weapons are protected from normal death drops.
- Cooldowns persist in `plugins/AstraSMP/players.yml`.
- Recipes are registered with unique NamespacedKeys.
- The 10-minute atmosphere is implemented server-side using time, particles, titles and sounds. Vanilla Paper cannot directly recolor the client's sky globally without client-side changes, so no client mod is required.
- Sudarshan Chakra is implemented as a bound Netherite Sword-style special weapon because a vanilla bow is not required for that Astra.

## Commands
See `plugin.yml` for the complete command and permission list.
