package com.astramp;

import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import java.util.*;

public final class AbilityManager {
    private final AstraSMP plugin;
    public AbilityManager(AstraSMP p){plugin=p;}
    public void use(Player p,AstraType a){
        Location l=p.getEyeLocation(); World w=p.getWorld();
        switch(a){
            case BRAHMASTRA -> projectile(p,a,ChatColor.BLUE,10,6,Particle.END_ROD);
            case BRAHMASHIRASTRA -> beam(p,a,12,Particle.DUST_PILLAR);
            case PASHUPATASTRA -> projectile(p,a,ChatColor.RED,9,7,Particle.CRIT);
            case NARAYANASTRA -> multi(p,a);
            case VAJRA -> lightning(p,a);
            case AGNEYASTRA -> fire(p,a);
            case VARUNASTRA -> water(p,a);
            case VAYAVASTRA -> wind(p,a);
            case NAGASTRA -> naga(p,a);
            case GARUDASTRA -> garuda(p,a);
            case SUDARSHAN -> chakra(p,a);
            case GANDIVA -> gandiva(p,a);
        }
        plugin.sky().activate(w,a,p.getLocation());
        p.sendMessage(plugin.msg("activated"));
        p.getWorld().playSound(p.getLocation(),Sound.ENTITY_LIGHTNING_BOLT_THUNDER,0.7f,1.0f);
    }
    private void projectile(Player p,AstraType a,ChatColor c,double damage,double radius,Particle particle){
        SmallFireball f=p.launchProjectile(SmallFireball.class);
        f.setVelocity(p.getEyeLocation().getDirection().multiply(1.35)); f.setIsIncendiary(false); f.setYield(0);
        plugin.track(f,a,p.getUniqueId(),damage,radius,particle);
    }
    private void beam(Player p,AstraType a,double damage,Particle pt){
        Vector d=p.getEyeLocation().getDirection().normalize(); Location c=p.getEyeLocation();
        for(int i=1;i<=18;i++){Location x=c.clone().add(d.clone().multiply(i)); p.getWorld().spawnParticle(pt,x,12,0.3,0.3,0.3,0.02);}
        damageNear(p,c.clone().add(d.multiply(9)),4,damage);
    }
    private void multi(Player p,AstraType a){
        List<Player> targets=new ArrayList<>();
        for(Entity e:p.getNearbyEntities(18,12,18))if(e instanceof Player q&&q!=p)targets.add(q);
        for(Player q:targets){
            Arrow ar=p.launchProjectile(Arrow.class); ar.setVelocity(q.getEyeLocation().toVector().subtract(p.getEyeLocation().toVector()).normalize().multiply(1.4));
            plugin.track(ar,a,p.getUniqueId(),5,2,Particle.END_ROD);
        }
    }
    private void lightning(Player p,AstraType a){
        Entity target=rayTarget(p,30); Location l=target!=null?target.getLocation():p.getTargetBlockExact(30)!=null?p.getTargetBlockExact(30).getLocation():p.getLocation();
        p.getWorld().strikeLightningEffect(l); damageNear(p,l,3,8);
    }
    private void fire(Player p,AstraType a){Fireball f=p.launchProjectile(Fireball.class);f.setVelocity(p.getEyeLocation().getDirection().multiply(1.0));f.setYield(0);f.setIsIncendiary(false);plugin.track(f,a,p.getUniqueId(),6,3,Particle.FLAME);}
    private void water(Player p,AstraType a){Location l=p.getLocation();for(Entity e:p.getNearbyEntities(8,5,8))if(e instanceof LivingEntity le&&le!=p){le.setVelocity(le.getLocation().toVector().subtract(l.toVector()).normalize().multiply(1.2));le.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,80,1));}p.getWorld().spawnParticle(Particle.SPLASH,l,100,4,2,4,0.4);}
    private void wind(Player p,AstraType a){Location l=p.getLocation();for(Entity e:p.getNearbyEntities(10,6,10))if(e instanceof LivingEntity le&&le!=p){Vector v=le.getLocation().toVector().subtract(l.toVector()).normalize().multiply(2.0);v.setY(1.0);le.setVelocity(v);}p.getWorld().spawnParticle(Particle.GUST,l,30,4,2,4,0.1);}
    private void naga(Player p,AstraType a){projectile(p,a,ChatColor.GREEN,5,2,Particle.SNEEZE);}
    private void garuda(Player p,AstraType a){p.removePotionEffect(PotionEffectType.POISON);projectile(p,a,ChatColor.GOLD,7,3,Particle.FIREWORK);}
    private void chakra(Player p,AstraType a){
        Location start=p.getEyeLocation(); Vector d=start.getDirection().normalize(); 
        for(int i=1;i<=20;i++){Location x=start.clone().add(d.clone().multiply(i));p.getWorld().spawnParticle(Particle.ENCHANT,x,12,0.2,0.2,0.2,0.1);}
        damageNear(p,start.clone().add(d.multiply(12)),3,9);
        p.getWorld().playSound(p.getLocation(),Sound.ENTITY_PLAYER_ATTACK_CRIT,1.0f,1.7f);
    }
    private void gandiva(Player p,AstraType a){Arrow ar=p.launchProjectile(Arrow.class);ar.setVelocity(p.getEyeLocation().getDirection().multiply(3.0));ar.setCritical(true);plugin.track(ar,a,p.getUniqueId(),7,2,Particle.END_ROD);}
    private void damageNear(Player owner,Location c,double radius,double damage){
        for(Entity e:c.getWorld().getNearbyEntities(c,radius,radius,radius))if(e instanceof LivingEntity le&&le!=owner)le.damage(damage*plugin.getConfig().getDouble("ability-damage-multiplier",1.0),owner);
        c.getWorld().spawnParticle(Particle.EXPLOSION_EMITTER,c,1);
    }
    private Entity rayTarget(Player p,double range){
        RayTraceResult r=p.getWorld().rayTraceEntities(p.getEyeLocation(),p.getEyeLocation().getDirection(),range,e->e!=p);
        return r==null?null:r.getHitEntity();
    }
}
