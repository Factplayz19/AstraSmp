package com.astramp;

import org.bukkit.Material;
import java.util.Locale;

public enum AstraType {
    BRAHMASTRA("Brahmastra","BRAHMASTRA BOW",1800,Material.NETHER_STAR,"BLUE"),
    BRAHMASHIRASTRA("Brahmashirastra","BRAHMASHIRASTRA BOW",3600,Material.NETHER_STAR,"RED"),
    PASHUPATASTRA("Pashupatastra","PASHUPATASTRA BOW",2700,Material.NETHER_STAR,"RED"),
    NARAYANASTRA("Narayanastra","NARAYANASTRA BOW",2400,Material.NETHER_STAR,"ORANGE"),
    VAJRA("Vajra","VAJRA BOW",900,Material.IRON_BLOCK,"ORANGE"),
    AGNEYASTRA("Agneyastra","AGNEYASTRA BOW",600,Material.BLAZE_ROD,"ORANGE"),
    VARUNASTRA("Varunastra","VARUNASTRA BOW",600,Material.PRISMARINE_CRYSTALS,"BLUE"),
    VAYAVASTRA("Vayavastra","VAYAVASTRA BOW",600,Material.FEATHER,"BLUE"),
    NAGASTRA("Nagastra","NAGASTRA BOW",900,Material.SPIDER_EYE,"RED"),
    GARUDASTRA("Garudastra","GARUDASTRA BOW",900,Material.FEATHER,"ORANGE"),
    SUDARSHAN("Sudarshan Chakra","SUDARSHAN CHAKRA",1200,Material.GOLD_BLOCK,"ORANGE"),
    GANDIVA("Gandiva","GANDIVA BOW",300,Material.DIAMOND,"ORANGE");

    private final String displayName, itemName, sky;
    private final int cooldown;
    private final Material icon;

    AstraType(String displayName,String itemName,int cooldown,Material icon,String sky){
        this.displayName=displayName; this.itemName=itemName; this.cooldown=cooldown; this.icon=icon; this.sky=sky;
    }
    public String displayName(){return displayName;}
    public String itemName(){return itemName;}
    public int cooldown(){return cooldown;}
    public Material icon(){return icon;}
    public String sky(){return sky;}
    public static AstraType from(String s){
        if(s==null)return null;
        String n=s.replace(" ","").replace("-","").toUpperCase(Locale.ROOT);
        if(n.equals("SUDARSHANCHAKRA"))n="SUDARSHAN";
        try{return valueOf(n);}catch(Exception e){return null;}
    }
}
