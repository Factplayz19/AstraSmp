package com.astramp;

import org.bukkit.*;
import org.bukkit.scheduler.BukkitTask;
import java.util.*;

public final class SkyEffectManager {
    private final AstraSMP plugin;
    private final Map<UUID, Active> worlds=new HashMap<>();
    private BukkitTask task;
    public SkyEffectManager(AstraSMP p){plugin=p; task=plugin.getServer().getScheduler().runTaskTimer(plugin,this::tick,20,20);}
    public void activate(World w,AstraType a,Location loc){
        worlds.put(w.getUID(),new Active(a,System.currentTimeMillis()+plugin.getConfig().getLong("sky-effect-duration-seconds",600)*1000L,loc.clone()));
        w.setStorm(false); w.setThundering(false);
        w.setTime(18000);
        for(Player p:w.getPlayers()){
            p.sendTitle(ChatColor.DARK_PURPLE+"⚡ DIVINE ASTRA ⚡",ChatColor.GRAY+"The heavens have been disturbed...",10,50,10);
            p.playSound(p.getLocation(),Sound.ENTITY_WITHER_SPAWN,0.55f,0.8f);
        }
    }
    private void tick(){
        long now=System.currentTimeMillis();
        Iterator<Map.Entry<UUID,Active>> it=worlds.entrySet().iterator();
        while(it.hasNext()){
            var e=it.next(); Active a=e.getValue(); World w=plugin.getServer().getWorld(e.getKey());
            if(w==null||now>=a.until){ if(w!=null)for(Player p:w.getPlayers())p.sendMessage(plugin.msg("faded")); it.remove(); continue; }
            if(plugin.getConfig().getBoolean("ambient-particles",true)){
                Particle pt=switch(a.astra.sky()){case "BLUE"->Particle.SOUL_FIRE_FLAME;case "RED"->Particle.DUST_PILLAR;default->Particle.FLAME;};
                Location c=a.location;
                for(int i=0;i<12;i++){
                    double ang=i*Math.PI/6; w.spawnParticle(pt,c.clone().add(Math.cos(ang)*6,2+Math.sin(i)*1.5,Math.sin(ang)*6),2,0.2,0.2,0.2,0.01);
                }
            }
        }
    }
    public void shutdown(){if(task!=null)task.cancel();}
    private record Active(AstraType astra,long until,Location location){}
}
