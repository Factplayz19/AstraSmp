package com.astramp;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import java.util.*;

public final class AstraSMP extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {
    private DataManager data; private BowManager bows; private SkyEffectManager sky; private AbilityManager abilities;
    private final Map<UUID,Long> spinning=new HashMap<>();
    private final Map<Projectile,Track> tracked=new HashMap<>();
    private BukkitTask saveTask;

    @Override public void onEnable(){
        saveDefaultConfig(); if(!new java.io.File(getDataFolder(),"messages.yml").exists())saveResource("messages.yml",false);
        data=new DataManager(this); bows=new BowManager(this); sky=new SkyEffectManager(this); abilities=new AbilityManager(this);
        getServer().getPluginManager().registerEvents(this,this);
        String[] cmds={"astra","spin","giveastra","removeastra","resetspin","givebrahmastra","givebrahmashirastra","givepashupatastra","givenarayanastra","givevajra","giveagneyastra","givevarunastra","givevayavastra","givenagastra","givegarudastra","givesudarshan","givegandiva","astrareload","astracooldown"};
        for(String c:cmds){PluginCommand pc=getCommand(c);if(pc!=null){pc.setExecutor(this);pc.setTabCompleter(this);}}
        saveTask=getServer().getScheduler().runTaskTimerAsynchronously(this,data::save,20*60,20*60);
        getLogger().info("AstraSMP enabled.");
    }
    @Override public void onDisable(){if(saveTask!=null)saveTask.cancel();data.save();sky.shutdown();}
    public DataManager data(){return data;} public BowManager bows(){return bows;} public SkyEffectManager sky(){return sky;}
    public String msg(String key){String s=getConfig().getString("messages."+key,"");return ChatColor.translateAlternateColorCodes('&',s);}
    @EventHandler public void join(PlayerJoinEvent e){
        Player p=e.getPlayer(); DataManager.PlayerData d=data.get(p.getUniqueId());
        if(d==null&&getConfig().getBoolean("first-join-spin",true)){p.sendMessage(msg("first-join"));startSpin(p);}
        else if(d!=null){bows.ensureBow(p,d.astra());}
    }
    private void startSpin(Player p){
        if(spinning.containsKey(p.getUniqueId()))return;
        spinning.put(p.getUniqueId(),System.currentTimeMillis());
        long duration=getConfig().getLong("spin-animation-ticks",50);
        getServer().getScheduler().runTaskTimer(this,new Runnable(){
            int t=0;
            public void run(){
                if(!p.isOnline()){spinning.remove(p.getUniqueId());return;}
                t+=5; AstraType[] a=AstraType.values(); AstraType shown=a[(t/5)%a.length];
                p.sendActionBar(ChatColor.YELLOW+"Spinning... "+ChatColor.GOLD+shown.displayName());
                if(t>=duration){
                    AstraType chosen=a[new Random().nextInt(a.length)];
                    data.create(p.getUniqueId(),chosen);data.save();spinning.remove(p.getUniqueId());
                    p.sendMessage(msg("spin-result").replace("%astra%",chosen.displayName()));bows.ensureBow(p,chosen);
                    throw new StopSpin();
                }
            }
        },0,5);
    }
    private static final class StopSpin extends RuntimeException{}
    @EventHandler public void interact(PlayerInteractEvent e){
        if(e.getAction()!=Action.RIGHT_CLICK_AIR&&e.getAction()!=Action.RIGHT_CLICK_BLOCK)return;
        ItemStack item=e.getItem(); if(!bows.isAstra(item))return;
        Player p=e.getPlayer(); AstraType a=bows.type(item); UUID owner=bows.owner(item);
        if(owner==null||!p.getUniqueId().equals(owner)){e.setCancelled(true);p.sendMessage(msg("owner-only"));return;}
        DataManager.PlayerData d=data.get(p.getUniqueId()); if(d==null||d.astra()!=a){e.setCancelled(true);return;}
        long remaining=(d.lastUse()+a.cooldown()*1000L)-System.currentTimeMillis();
        if(remaining>0){p.sendActionBar(msg("cooldown").replace("%astra%",a.displayName()).replace("%time%",format(remaining/1000)));e.setCancelled(true);return;}
        e.setCancelled(true);
        data.update(d,d.firstSpin(),System.currentTimeMillis(),d.uses()+1,true);data.save();
        abilities.use(p,a);
    }
    @EventHandler public void projectileHit(ProjectileHitEvent e){
        Track t=tracked.remove(e.getEntity()); if(t==null)return;
        Location l=e.getHitEntity()!=null?e.getHitEntity().getLocation():e.getEntity().getLocation();
        if(e.getHitEntity() instanceof LivingEntity le){
            Player owner=getServer().getPlayer(t.owner); if(owner!=null&&le!=owner)le.damage(t.damage,owner);
        }
        l.getWorld().spawnParticle(t.particle,l,45,1.5,1.5,1.5,0.1);
        for(Entity x:l.getWorld().getNearbyEntities(l,t.radius,t.radius,t.radius))
            if(x instanceof LivingEntity le&&!(x instanceof Player)&&getServer().getPlayer(t.owner)!=x)le.damage(t.damage*0.5);
    }
    public void track(Projectile p,AstraType a,UUID owner,double damage,double radius,Particle particle){tracked.put(p,new Track(owner,damage,radius,particle));}
    @EventHandler public void death(PlayerDeathEvent e){
        if(!getConfig().getBoolean("death-protection",true))return;
        Player p=e.getEntity(); DataManager.PlayerData d=data.get(p.getUniqueId()); if(d==null)return;
        e.getDrops().removeIf(bows::isAstra);p.sendMessage(msg("protected"));
    }
    @EventHandler public void respawn(PlayerRespawnEvent e){DataManager.PlayerData d=data.get(e.getPlayer().getUniqueId());if(d!=null)getServer().getScheduler().runTaskLater(this,()->bows.ensureBow(e.getPlayer(),d.astra()),1);}
    @EventHandler public void click(InventoryClickEvent e){if(e.getView().getTitle().equals(ChatColor.GOLD+"✦ YOUR ASTRA"))e.setCancelled(true);}
    @Override public boolean onCommand(CommandSender s,Command c,String l,String[] a){
        String n=c.getName().toLowerCase(Locale.ROOT);
        if(n.equals("astra")){if(a.length>0&&!s.hasPermission("astrasmp.admin")){s.sendMessage(msg("no-permission"));return true;}Player p=a.length>0?getServer().getPlayer(a[0]):(s instanceof Player q?q:null);if(p==null){s.sendMessage(ChatColor.RED+"Player not found.");return true;}showInfo(s,p);return true;}
        if(n.equals("astrareload")){if(!s.hasPermission("astrasmp.reload")){s.sendMessage(msg("no-permission"));return true;}reloadConfig();s.sendMessage(ChatColor.GREEN+"AstraSMP reloaded.");return true;}
        if(n.equals("spin")){if(!s.hasPermission("astrasmp.spin"))return deny(s);Player p=player(a,0);if(p!=null){data.remove(p.getUniqueId());startSpin(p);}return true;}
        if(n.equals("giveastra")){if(!s.hasPermission("astrasmp.give"))return deny(s);if(a.length<2)return false;Player p=player(a,0);AstraType x=AstraType.from(a[1]);if(p!=null&&x!=null){data.create(p.getUniqueId(),x);bows.ensureBow(p,x);p.sendMessage(msg("spin-result").replace("%astra%",x.displayName()));}else s.sendMessage(msg("invalid-astra"));return true;}
        if(n.equals("removeastra")){if(!s.hasPermission("astrasmp.remove"))return deny(s);Player p=player(a,0);if(p!=null){data.remove(p.getUniqueId());p.getInventory().removeIf(bows::isAstra);s.sendMessage(ChatColor.GREEN+"Astra removed.");}return true;}
        if(n.equals("resetspin")){if(!s.hasPermission("astrasmp.admin"))return deny(s);Player p=player(a,0);if(p!=null){data.remove(p.getUniqueId());s.sendMessage(ChatColor.GREEN+"Spin reset.");}return true;}
        if(n.equals("astracooldown")){if(!s.hasPermission("astrasmp.admin"))return deny(s);Player p=player(a,0);if(p!=null&&a.length>1&&a[1].equalsIgnoreCase("reset")){var d=data.get(p.getUniqueId());if(d!=null){data.update(d,d.firstSpin(),0,d.uses(),d.spun());s.sendMessage(ChatColor.GREEN+"Cooldown reset.");}}return true;}
        if(n.startsWith("give")){
            if(!s.hasPermission("astrasmp.give"))return deny(s);
            String key=n.substring(4);AstraType x=AstraType.from(key);if(n.equals("givesudarshan"))x=AstraType.SUDARSHAN;
            Player p=player(a,0);if(p!=null&&x!=null)p.getInventory().addItem(bows.weapon(x,p.getUniqueId()));return true;
        }
        return false;
    }
    private boolean deny(CommandSender s){s.sendMessage(msg("no-permission"));return true;}
    private Player player(String[] a,int i){return a.length>i?getServer().getPlayerExact(a[i]):null;}
    private void showInfo(CommandSender s,Player p){
        var d=data.get(p.getUniqueId());if(d==null){s.sendMessage(ChatColor.RED+"No Astra assigned.");return;}
        s.sendMessage(ChatColor.GOLD+"✦ "+p.getName()+"'s ASTRA");
        s.sendMessage(ChatColor.YELLOW+"Astra: "+d.astra().displayName());
        s.sendMessage(ChatColor.GRAY+"Cooldown: "+d.astra().cooldown()/60+" minutes");
        s.sendMessage(ChatColor.GRAY+"Uses: "+d.uses());
        s.sendMessage(ChatColor.GRAY+"Owner UUID: "+p.getUniqueId());
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String l,String[] a){
        String n=c.getName().toLowerCase(Locale.ROOT);List<String> out=new ArrayList<>();
        if(a.length==1&&Set.of("spin","giveastra","removeastra","resetspin","astra","givebrahmastra","givebrahmashirastra","givepashupatastra","givenarayanastra","givevajra","giveagneyastra","givevarunastra","givevayavastra","givenagastra","givegarudastra","givesudarshan","givegandiva","astracooldown").contains(n))for(Player p:getServer().getOnlinePlayers())out.add(p.getName());
        if(a.length==2&&n.equals("giveastra"))for(AstraType x:AstraType.values())out.add(x.name().toLowerCase());
        if(a.length==2&&n.equals("astracooldown"))out.add("reset");
        return out;
    }
    private String format(long s){long m=s/60;long sec=s%60;return m+"m "+sec+"s";}
    private record Track(UUID owner,double damage,double radius,Particle particle){}
}
