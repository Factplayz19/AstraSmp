package com.astramp;

import org.bukkit.plugin.java.JavaPlugin;
import java.io.*;
import java.util.*;

public final class DataManager {
    private final JavaPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerData> data = new HashMap<>();

    public DataManager(JavaPlugin plugin){
        this.plugin=plugin; this.file=new File(plugin.getDataFolder(),"players.yml");
        load();
    }
    public synchronized void load(){
        data.clear();
        if(!file.exists())return;
        try(var in=new java.io.FileInputStream(file)){
            Properties p=new Properties(); p.load(in);
            Set<String> ids=new HashSet<>();
            for(String k:p.stringPropertyNames()){
                if(k.endsWith(".astra")) ids.add(k.substring(0,k.length()-6));
            }
            for(String id:ids){
                UUID u=UUID.fromString(id);
                AstraType a=AstraType.from(p.getProperty(id+".astra"));
                long first=Long.parseLong(p.getProperty(id+".first","0"));
                long last=Long.parseLong(p.getProperty(id+".last","0"));
                int uses=Integer.parseInt(p.getProperty(id+".uses","0"));
                boolean spun=Boolean.parseBoolean(p.getProperty(id+".spun","false"));
                if(a!=null)data.put(u,new PlayerData(u,a,first,last,uses,spun));
            }
        }catch(Exception e){plugin.getLogger().warning("Could not load players.yml: "+e.getMessage());}
    }
    public synchronized void save(){
        try{
            plugin.getDataFolder().mkdirs();
            Properties p=new Properties();
            for(PlayerData d:data.values()){
                String id=d.uuid().toString();
                p.setProperty(id+".astra",d.astra().name());
                p.setProperty(id+".first",Long.toString(d.firstSpin()));
                p.setProperty(id+".last",Long.toString(d.lastUse()));
                p.setProperty(id+".uses",Integer.toString(d.uses()));
                p.setProperty(id+".spun",Boolean.toString(d.spun()));
            }
            try(var out=new FileOutputStream(file)){p.store(out,"AstraSMP player data");}
        }catch(IOException e){plugin.getLogger().warning("Could not save players.yml: "+e.getMessage());}
    }
    public PlayerData get(UUID u){return data.get(u);}
    public void put(PlayerData d){data.put(d.uuid(),d);}
    public void remove(UUID u){data.remove(u);}
    public record PlayerData(UUID uuid,AstraType astra,long firstSpin,long lastUse,int uses,boolean spun){}
    public PlayerData update(PlayerData old,long first,long last,int uses,boolean spun){
        PlayerData n=new PlayerData(old.uuid(),old.astra(),first,last,uses,spun); put(n); return n;
    }
    public PlayerData create(UUID u,AstraType a){
        PlayerData d=new PlayerData(u,a,System.currentTimeMillis(),0,0,true);put(d);return d;
    }
}
