package com.astramp;

import org.bukkit.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.persistence.PersistentDataContainer;
import java.util.*;

public final class BowManager {
    private final AstraSMP plugin;
    public final NamespacedKey astraKey, ownerKey, chakraKey;
    public BowManager(AstraSMP p){
        plugin=p; astraKey=new NamespacedKey(p,"astra"); ownerKey=new NamespacedKey(p,"owner"); chakraKey=new NamespacedKey(p,"chakra");
        registerRecipes();
    }
    public ItemStack weapon(AstraType type, UUID owner){
        Material mat=type==AstraType.SUDARSHAN?Material.NETHERITE_SWORD:Material.BOW;
        ItemStack item=new ItemStack(mat);
        ItemMeta m=item.getItemMeta();
        m.setDisplayName(ChatColor.GOLD+"✦ "+type.itemName());
        List<String> lore=new ArrayList<>();
        lore.add(ChatColor.GRAY+"Divine weapon of "+type.displayName());
        lore.add(ChatColor.DARK_GRAY+"Bound to: "+owner);
        lore.add(ChatColor.YELLOW+"Ability: "+type.displayName());
        lore.add(ChatColor.RED+"Cooldown: "+format(type.cooldown()));
        m.setLore(lore); m.setUnbreakable(true);
        m.addEnchant(Enchantment.UNBREAKING,1,true);
        PersistentDataContainer p=m.getPersistentDataContainer();
        p.set(astraKey,PersistentDataType.STRING,type.name());
        p.set(ownerKey,PersistentDataType.STRING,owner.toString());
        if(type==AstraType.SUDARSHAN)p.set(chakraKey,PersistentDataType.BYTE,(byte)1);
        item.setItemMeta(m); return item;
    }
    public boolean isAstra(ItemStack item){
        if(item==null||!item.hasItemMeta())return false;
        return item.getItemMeta().getPersistentDataContainer().has(astraKey,PersistentDataType.STRING);
    }
    public AstraType type(ItemStack item){
        if(!isAstra(item))return null;
        String s=item.getItemMeta().getPersistentDataContainer().get(astraKey,PersistentDataType.STRING);
        return AstraType.from(s);
    }
    public UUID owner(ItemStack item){
        if(!isAstra(item))return null;
        String s=item.getItemMeta().getPersistentDataContainer().get(ownerKey,PersistentDataType.STRING);
        try{return UUID.fromString(s);}catch(Exception e){return null;}
    }
    public void ensureBow(Player p,AstraType a){
        for(ItemStack i:p.getInventory().getContents())
            if(isAstra(i)&&type(i)==a&&p.getUniqueId().equals(owner(i)))return;
        if(p.getInventory().firstEmpty()>=0)p.getInventory().addItem(weapon(a,p.getUniqueId()));
        else p.getWorld().dropItemNaturally(p.getLocation(),weapon(a,p.getUniqueId()));
    }
    private void registerRecipes(){
        for(AstraType a:AstraType.values()){
            if(a==AstraType.SUDARSHAN) registerSudarshan(); else registerBowRecipe(a);
        }
    }
    private void registerBowRecipe(AstraType a){
        ItemStack out=weapon(a,new UUID(0,0));
        NamespacedKey key=new NamespacedKey(plugin,"recipe_"+a.name().toLowerCase());
        ShapedRecipe r=new ShapedRecipe(key,out);
        switch(a){
            case BRAHMASTRA -> {r.shape("NNN","DSD","NNN"); r.setIngredient('N',Material.NETHER_STAR);r.setIngredient('D',Material.DIAMOND_BLOCK);r.setIngredient('S',Material.STICK);}
            case BRAHMASHIRASTRA -> {r.shape("NEN","ECE","NEN");r.setIngredient('N',Material.NETHER_STAR);r.setIngredient('E',Material.ECHO_SHARD);r.setIngredient('C',Material.CONDUIT);}
            case PASHUPATASTRA -> {r.shape("DWD","NSN","DWD");r.setIngredient('D',Material.DIAMOND);r.setIngredient('W',Material.WITHER_SKELETON_SKULL);r.setIngredient('N',Material.NETHER_STAR);r.setIngredient('S',Material.STICK);}
            case NARAYANASTRA -> {r.shape("NGN","GHG","NGN");r.setIngredient('N',Material.NETHER_STAR);r.setIngredient('G',Material.GOLD_BLOCK);r.setIngredient('H',Material.HEART_OF_THE_SEA);}
            case VAJRA -> {r.shape("III","DSD","III");r.setIngredient('I',Material.IRON_BLOCK);r.setIngredient('D',Material.DIAMOND);r.setIngredient('S',Material.STICK);}
            case AGNEYASTRA -> {r.shape("BFB","FSF","BFB");r.setIngredient('B',Material.BLAZE_ROD);r.setIngredient('F',Material.FIRE_CHARGE);r.setIngredient('S',Material.STICK);}
            case VARUNASTRA -> {r.shape("PHP","HSH","PHP");r.setIngredient('P',Material.PRISMARINE_CRYSTALS);r.setIngredient('H',Material.HEART_OF_THE_SEA);r.setIngredient('S',Material.STICK);}
            case VAYAVASTRA -> {r.shape("FPF","PSP","FPF");r.setIngredient('F',Material.FEATHER);r.setIngredient('P',Material.PHANTOM_MEMBRANE);r.setIngredient('S',Material.STICK);}
            case NAGASTRA -> {r.shape("SSS","GBG","SSS");r.setIngredient('S',Material.SPIDER_EYE);r.setIngredient('G',Material.GOLD_INGOT);r.setIngredient('B',Material.BOW);}
            case GARUDASTRA -> {r.shape("FGF","GSG","FGF");r.setIngredient('F',Material.FEATHER);r.setIngredient('G',Material.GOLD_INGOT);r.setIngredient('S',Material.STICK);}
            case GANDIVA -> {r.shape("DDD","ESE","DDD");r.setIngredient('D',Material.DIAMOND);r.setIngredient('E',Material.EMERALD);r.setIngredient('S',Material.STICK);}
            default -> {}
        }
        plugin.getServer().addRecipe(r);
    }
    private void registerSudarshan(){
        ItemStack out=weapon(AstraType.SUDARSHAN,new UUID(0,0));
        ShapedRecipe r=new ShapedRecipe(new NamespacedKey(plugin,"recipe_sudarshan"),out);
        r.shape("GNG","NCN","GNG");r.setIngredient('G',Material.GOLD_BLOCK);r.setIngredient('N',Material.NETHER_STAR);r.setIngredient('C',Material.COPPER_BLOCK);
        plugin.getServer().addRecipe(r);
    }
    private String format(long s){return s/60+"m";}
}
